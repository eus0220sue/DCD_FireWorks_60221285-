public enum ESceneType
{
    Start,
    Title,
    Animator,
}

public enum GameState
{
    Play,
    Pause,
    Result,
}
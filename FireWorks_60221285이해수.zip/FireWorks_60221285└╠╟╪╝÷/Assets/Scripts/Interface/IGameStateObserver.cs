public interface IGameStateObserver
{
    void OnGameStateChange(GameState newState);
}

#
#		Firework Particle System Collection
#		
#		FEATURES
#		• Shuriken Particle Systems
#		• Colors changeable within Unity
#		• Includes Particle Scale Tool (Window/Simple Particle Scale)
#		
#		UPDATE +1
#		• Added 20 Particle System Prefabs
#		
#		UPDATE +2
#		• Added Sounds and Sound Scripts
#		• Added 5 Sound Script Examples 
#		
#		UPDATE +3
#		• Added Optimized and Mobile versions of each effect
#		
#		
#		
#		
#		Unluck Software
#		http://www.chemicalbliss.com/
#		
#		Thanks for purchasing this asset
#		Have fun with Unity!
#		
FEATURES

 		• Scale Particles 
                A simple function that helps with scaling all selected particle systems 
        • Save Prefabs 
                Creates prefabs from selected gameObjects 
       

The tool is located in "Window/Simple Particle Scale"


Unluck Software
http://www.chemicalbliss.com/

Thanks for purchasing this asset
Have fun with Unity!
